<script type="text/javascript">
setTimeout("document.location= document.location",2000)


</script>